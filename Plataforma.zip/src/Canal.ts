class Canal {
  nombre: string;
  banner: string;
  streamer: string;
  descripcion: string;

  constructor(nombre: string, banner: string, streamer: string, descripcion: string) {
    this.nombre = nombre;
    this.banner = banner;
    this.streamer = streamer;
    this.descripcion = descripcion;
  }
}